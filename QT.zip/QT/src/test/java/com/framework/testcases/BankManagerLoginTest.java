package com.framework.testcases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.framework.base.TestBase;

public class BankManagerLoginTest extends TestBase {

	@Test
	public void bankManagerLoginTest() throws IOException, InterruptedException {
		//If we dont add this line we will see plan text intead of the link 
		System.setProperty("org.uncommons.reportng.escape-output","false");
		
		
		//Hard Assertion: Test cases fails it wont execute remaining lines of the code also it fails other test cases
		//Assert.assertEquals("abc","XYZ");
		
		
		//SoftAsseration: test execution will not halt even assertion fails 
		/*try
		{
			Assert.assertEquals("abc","XYZ");
			System.out.println("After assertion");
		}
		catch (Throwable t) {
			System.out.println("Inside Catch");
			
		}*/
		
		
		verifyEquals("abc", "xyz");
		Thread.sleep(3000);
		log.debug("Inside Login Test");

		log.debug("Inside Login Test");
		
		click("bmlBtn_CSS");
		//driver.findElement(By.cssSelector(OR.getProperty("bmlBtn"))).click();
		Assert.assertTrue(isElementPresent(By.cssSelector(OR.getProperty("addCustBtn_CSS"))), "Login Not succesfull");
		
		
		log.debug("Login successfully executed");
		//Assert.fail("Login not successful");
		
		//Reporter.log("Login is succesfull");
		//open the same page
		//Reporter.log("<a href=\"C:\\Users\\Public\\Pictures\\Sample Pictures\">Screenshot</a>");
		
		//opens in New tab
		//Reporter.log("<a target=\"_blank\" href=\"C:\\Users\\Public\\Pictures\\Sample Pictures\">Screenshot</a>");
	}

}
