package com.framework.testcases;

import java.util.Hashtable;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.framework.base.TestBase;
import com.framework.utilities.TestUtil;

public class AddCustomerTest extends TestBase{
	
	//@Test(dataProvider = "getData")
	
	@Test(dataProviderClass=TestUtil.class,dataProvider="dp")
//	public void addCustomerTest(String firstName,String lastName, String postCode,String alerttext)
	public void addCustomerTest(Hashtable<String,String> data) throws InterruptedException

	{


		/*click("addCustBtn_CSS");
		type("firstname_CSS",firstName);
		type("lastname_XPATH",lastName);
		type("postcode_CSS",postCode);
		click("addbtn_CSS");*/
	
		
		/*driver.findElement(By.cssSelector(OR.getProperty("addCust1"))).click();
	
		driver.findElement(By.cssSelector(OR.getProperty("firstName"))).sendKeys(firstName);
		driver.findElement(By.cssSelector(OR.getProperty("lastName"))).sendKeys(lastName);
		driver.findElement(By.cssSelector(OR.getProperty("postCode"))).sendKeys(postCode);
		driver.findElement(By.cssSelector(OR.getProperty("addBtn"))).click();*/
		
		/*Alert alert=wait.until(ExpectedConditions.alertIsPresent());
		Assert.assertTrue(alert.getText().contains(alerttext)); 
		alert.accept();*/
		
		click("addCustBtn_CSS");
		type("firstname_CSS",data.get("firstname"));
		type("lastname_XPATH",data.get("lastname"));
		type("postcode_CSS",data.get("postcode"));
		click("addbtn_CSS");
		
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		
		Assert.assertTrue(alert.getText().contains(data.get("alerttext")));
		alert.accept();
		
		Thread.sleep(2000);
		

	}
	
	
	//Instead of writting this code in each & every class make it as generic(Optimization)
	/*@DataProvider
	 * 
	 * Return data:we are passing same data to addCustomerTest method with the help of dataprovider (@Test(dataProvider = "getData"))
	public Object[][] getData()
	{
		
     String sheetName="AddCustomerTest";
     int rows=excel.getRowCount(sheetName);
     int cols=excel.getColumnCount(sheetName);
     
     Object[][] data = new Object[rows-1][cols];
     
     for(int rowNum=2;rowNum<=rows;rowNum++)
     {
    	 for(int colNum=0;colNum<cols;colNum++)
    	 {
    		 data[rowNum-2][colNum]=excel.getCellData(sheetName, colNum, rowNum);
    		 
    	 }
     }
              return data;
	}*/

}
