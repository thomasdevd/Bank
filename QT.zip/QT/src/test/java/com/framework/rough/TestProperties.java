package com.framework.rough;

import java.util.Properties;

public class TestProperties {
	
	public static void main(String[] args)
	{
 Properties config = new Properties();

}
}
